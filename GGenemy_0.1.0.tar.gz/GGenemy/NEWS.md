# GGenemy 0.0.0.9000

* Initial development version
* Color accessibility checking with `gg_audit_color()`
* Colorblind vision simulation with `gg_simulate_cvd()`
* Scale and axis auditing with `gg_audit_scales()`
* Text readability checks with `gg_audit_text()`
* Label auditing with `gg_audit_labels()`
* Accessibility checks with `gg_audit_accessibility()`
* Comprehensive audit function `gg_audit()`
* Automatic fix suggestions with `gg_suggest_fixes()`
